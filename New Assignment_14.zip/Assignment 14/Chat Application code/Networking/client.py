import socket
from tkinter import *

def send(listbox, entry):
    message = entry.get()
    listbox.insert(END, "client: " + message)
    entry.delete(0, END)
    s.send(bytes(message, 'utf-8'))

def receive(listbox):
    message = s.recv(1024)
    listbox.insert(END, "server: " + message.decode('utf-8'))

root = Tk()
root.title("Client")

entry = Entry(root)
entry.pack(side=BOTTOM)

listbox = Listbox(root)
listbox.pack()

button = Button(root, text="send", command=lambda: send(listbox, entry))
button.pack(side=BOTTOM)

rbutton = Button(root, text="Receive", command=lambda: receive(listbox))
rbutton.pack(side=BOTTOM)

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
HOST_NAME = socket.gethostname()
PORT = 12345

s.connect((HOST_NAME, PORT))

root.mainloop()