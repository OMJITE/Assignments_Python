from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
import time

options = Options()
options.add_experimental_option("detach", True)
options.add_argument("--disable-notifications")

driver = webdriver.Chrome(options=options)
driver.get("https://www.facebook.com/")

driver.maximize_window()

emailelement=driver.find_element(By.ID ,"email")
emailelement.send_keys("omjite9298@gmail.com")

passelement = driver.find_element(By.ID, "pass")
passelement.send_keys("123@Henry")

elem=driver.find_element(By.NAME, "login")
elem.click()

time.sleep(5)
print("Opening post box...")
statuselement = driver.find_element(By.XPATH, "//span[contains(text(), \"What's on your mind\")]")
statuselement.click()

time.sleep(5)

print("Typing...")
input_box = driver.find_element(By.XPATH, "//div[@role='textbox']")
input_box.send_keys("Hi THERE")

time.sleep(5)

print("Clicking Post...")
post_button = driver.find_element(By.XPATH, "//div[@aria-label='Post']")
post_button.click()

time.sleep(30)
driver.quit()