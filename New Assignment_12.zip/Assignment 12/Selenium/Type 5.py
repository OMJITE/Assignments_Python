from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options

options = Options()
options.add_experimental_option("detach", True)

driver = webdriver.Chrome(options=options)
driver.get("https://www.amazon.in/ref=nav_logo")

driver.maximize_window()

driver.find_element(By.XPATH, "//*[@id='twotabsearchtextbox']").send_keys("Samsung")

driver.find_element(By.XPATH, "//*[@id='nav-search-submit-button']").click()

list = driver.find_elements(By.XPATH,"//span[@class='a-size-base-plus a-spacing-none a-color-base a-text-normal']")

print(str(len(list)) + " products found")


for i in list :

    print(i.text)

driver.quit()