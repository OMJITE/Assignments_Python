from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()
driver.get("https://www.amazon.in/ref=nav_logo")
driver.maximize_window()

time.sleep(2)

search = driver.find_element(By.LINK_TEXT, "Mobiles")
search.click()

time.sleep(2)

search_1 = driver.find_element(By.LINK_TEXT, "Electronics")
search_1.click()